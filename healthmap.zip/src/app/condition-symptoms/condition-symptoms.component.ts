import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-condition-symptoms',
  templateUrl: './condition-symptoms.component.html',
  styleUrls: ['./condition-symptoms.component.css']
})
export class ConditionSymptomsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
