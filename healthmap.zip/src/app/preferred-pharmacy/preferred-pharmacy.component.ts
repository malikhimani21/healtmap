import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-preferred-pharmacy',
  templateUrl: './preferred-pharmacy.component.html',
  styleUrls: ['./preferred-pharmacy.component.css']
})
export class PreferredPharmacyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
