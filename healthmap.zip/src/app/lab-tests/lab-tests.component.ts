import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab-tests',
  templateUrl: './lab-tests.component.html',
  styleUrls: ['./lab-tests.component.css']
})
export class LabTestsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
