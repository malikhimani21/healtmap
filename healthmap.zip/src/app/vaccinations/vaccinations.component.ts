import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vaccinations',
  templateUrl: './vaccinations.component.html',
  styleUrls: ['./vaccinations.component.css']
})
export class VaccinationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
