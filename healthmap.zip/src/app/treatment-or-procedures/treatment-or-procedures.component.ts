import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-treatment-or-procedures',
  templateUrl: './treatment-or-procedures.component.html',
  styleUrls: ['./treatment-or-procedures.component.css']
})
export class TreatmentOrProceduresComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
