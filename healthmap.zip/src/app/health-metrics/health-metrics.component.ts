import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-health-metrics',
  templateUrl: './health-metrics.component.html',
  styleUrls: ['./health-metrics.component.css']
})
export class HealthMetricsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
